df <- read_csv('dataset/netflix_titles.csv')


